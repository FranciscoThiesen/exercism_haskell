module Anagram (anagramsFor) where
import Data.MultiSet (MultiSet)
import qualified Data.MultiSet as MultiSet

anagramsFor :: String -> [String] -> [String]
anagramsFor xs xss = filter (\x -> (==) (fromList x) (fromList xs)) xss
